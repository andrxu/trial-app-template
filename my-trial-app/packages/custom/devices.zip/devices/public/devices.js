'use strict';

angular.module('mean.devices', []);
